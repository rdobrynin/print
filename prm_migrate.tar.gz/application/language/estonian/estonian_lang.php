<?php
$lang['menu_dashboard'] = "Dashboard";
$lang['menu_clients'] = "Kliendid";
$lang['menu_projects'] = "Projektid";
$lang['menu_tasks'] = "Ülesanne";
$lang['menu_team'] = "Rühm";
$lang['menu_chart'] = "Aruanne";
$lang['menu_comments'] = "Kommentaar";
$lang['menu_help'] = "Järele aitama";
$lang['menu_lang'] = "Keel";
$lang['menu_add_client'] = "Lisa klient";