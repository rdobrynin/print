    <div class="row-fluid">
        <div class="col-md-12" style="margin: 0; padding: 0">
            <div class="center-strip">
                <p class="lead">You have successfully registered</p>
            <a href="admin">    <button class="btn btn-large btn-primary log-success" style="width: 10%; font-size: 22px;" type="button">login</button></a>
            </div>
        </div>
    </div>
