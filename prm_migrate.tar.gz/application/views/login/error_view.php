<div class="e" style="width:365px; margin: 0 auto; margin-bottom:20px; height: 40px;">
    <div class="alert alert-danger alert-error error-frame" >
        <a href="#" class="close" data-dismiss="alert">&times;</a>
        <strong>Error!</strong> Wrong password. Try again please!
    </div>
</div>
