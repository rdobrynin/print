<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Brilliant Project management</title>

  <!-- Bootstrap core CSS -->
  <link href="<?php print(base_url());?>css/bootstrap.css" rel="stylesheet">

  <!-- Add custom CSS here -->
  <link href="<?php print(base_url());?>css/login.css" rel="stylesheet">
  <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
  <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic' rel='stylesheet' type='text/css'>

</head>

<body>
<div class="note-sound"></div>
