<!-- Page content -->
<div id="page-content-wrapper">

  <!-- Keep all page content within the page-content inset div! -->
  <div class="page-content inset">
    <h3>Comments</h3>
    <div class="row">

    </div>
  </div>
</div>
</div>
<?php include('footer_view.php');?>
