<div class="errors alert alert-danger alert-dismissible" role="alert"><?php echo validation_errors(); ?></div>
<!-- Page content -->
<div id="page-content-wrapper">
    <div class="page-content inset">
        <div class="row">

        </div>
    </div>
</div>
</div>
<?php include('footer_view.php'); ?>

