codeigniter 2.0

application kit with athorization and signing system


Includes frontend:

Bootstrap 3 UI
Font Awesome
